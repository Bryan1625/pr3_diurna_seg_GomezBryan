
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ProcessExample {
    public static void main(String[] args) throws IOException {
        // Llamada al sistema para listar los archivos en el directorio actual
        Process process1 = Runtime.getRuntime().exec("ls");

        // Llamada al proceso del usuario para imprimir un mensaje
        Process process2 = Runtime.getRuntime().exec("echo 'Hola, este es un mensaje desde el proceso del usuario'");

        // Leer la salida de los procesos
        BufferedReader reader1 = new BufferedReader(new InputStreamReader(process1.getInputStream()));
        String line;
        while ((line = reader1.readLine()) != null) {
            System.out.println(line);
        }
        reader1.close();

        BufferedReader reader2 = new BufferedReader(new InputStreamReader(process2.getInputStream()));
        while ((line = reader2.readLine()) != null) {
            System.out.println(line);
        }
        reader2.close();

        // Esperar a que los procesos terminen
        try {
            process1.waitFor();
            process2.waitFor();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

