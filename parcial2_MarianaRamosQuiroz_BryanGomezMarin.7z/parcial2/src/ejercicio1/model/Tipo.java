package ejercicio1.model;


public enum Tipo {
	
	amigos,trabajo,universidad;
}
