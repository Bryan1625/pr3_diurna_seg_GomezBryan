package programacion3.parcial3.servidor.ejercicio2;

public class MainServidor {

	public static void main(String[] args) {
		Servidor servidor= new Servidor();
		servidor.iniciarServidor();

	}

}
